<div id="all" class="container-fluid">
    <div id="content" class="container container mt-md-5 mt-4 mb-md-5 mb-4">
        {content}
        <main id="main">
            <div class="container"></div>
        </main>
    </div>
</div>
<!-- Animation CSS -->
<link rel="stylesheet" href="{theme_url}assets/css/animate.css" />
<!-- Latest Bootstrap min CSS -->
<link rel="stylesheet" href="{theme_url}assets/bootstrap/css/bootstrap.min.css" />
<!-- Google Font -->
<link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500,700,900" rel="stylesheet" />
<link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i"
    rel="stylesheet" />
<!-- Icon Font CSS -->
<link rel="stylesheet" href="{theme_url}assets/css/ionicons.min.css" />
<link rel="stylesheet" href="{theme_url}assets/css/themify-icons.css" />
<!-- FontAwesome CSS -->
<link rel="stylesheet" href="{theme_url}assets/css/all.min.css" />
<!--- owl carousel CSS-->
<link rel="stylesheet" href="{theme_url}assets/owlcarousel/css/owl.carousel.min.css" />
<link rel="stylesheet" href="{theme_url}assets/owlcarousel/css/owl.theme.css" />
<link rel="stylesheet" href="{theme_url}assets/owlcarousel/css/owl.theme.default.min.css" />
<!-- Magnific Popup CSS -->
<link rel="stylesheet" href="{theme_url}assets/css/magnific-popup.css" />
<!-- Style CSS -->
<link rel="stylesheet" href="{theme_url}assets/css/style.css" />
<link rel="stylesheet" href="{theme_url}assets/css/alumni.css" />
<link rel="stylesheet" href="{theme_url}assets/css/responsive.css" />
<link rel="stylesheet" id="layoutstyle" href="{theme_url}assets/color/theme.css" />
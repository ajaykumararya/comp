<section class="background_bg overlay_bg2 full_screen" style="background-color:#343333">
    <style>
        .background_bg {
            background-position: center bottom;
            background-size: auto;
            background-repeat: no-repeat;
        }
    </style>
    <div class="container h-100">
        <div class="row justify-content-center align-content-center h-100">
            <div class="col-md-8 col-sm-8">
                <div class="text-center">
                    <div class="error_txt">404</div>
                    <h4 class="text_white" style="color:#ffffff;">Sorry We Can't Find That Page!</h4>
                    <h6 style="color:#ffffff;">The page you are looking for was moved, removed, renamed or never
                        existed.</h6>
                    <a href="{base_url}" class="btn btn-default">Back To Home</a>
                </div>
            </div>
        </div>
    </div>
</section>
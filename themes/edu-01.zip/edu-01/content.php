<?php
if (trim($content) != ''):
    ?>
    <section class="padding-lg">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    {content}
                </div>
            </div>
        </div>
    </section>
    <?php
endif;
?>
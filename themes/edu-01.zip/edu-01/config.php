<?php
$config['footer_sections'] = [
    'footer_first' => 'Usefull Links',
    'footer_second' => 'Second Section',
    'footer_third' => 'Third Section',
    'footer_forth' => 'Forth Section'
];